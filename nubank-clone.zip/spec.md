# Nubank Clone

## Current State
The app has a login screen with a 4-digit PIN, a main home screen with:
- Purple header with profile/eye/help/invite icons
- Balance card with click-to-edit
- Quick action buttons (Pix, Pagar, Transferir, Depositar)
- Credit card section with limit bar
- Transaction list
- Hidden notification trigger

## Requested Changes (Diff)

### Add
- "Olá, [Nome]" greeting prominently below the header icons row
- Simulated screen transitions: clicking Área Pix, Pagar, Transferir opens dedicated sub-screens
- Empréstimo section card with simulated values
- Investimentos section card with simulated values
- Nu Shopping section card
- Meus cartões card with phone/card icon
- "Área Pix" as a separate button/shortcut distinct from just "Pix"

### Modify
- Header: profile icon left + greeting below, icons right aligned; faithful purple layout
- Quick action icons: light gray circle (#F0F0F0) with black symbols, exactly like Nubank
- Font: use 'Inter' or closest available (Graphik substitute)
- USER_NAME, BALANCE, CREDIT_LIMIT, CREDIT_USED as easy-edit top-level constants
- All cards and sections scrollable with all Nubank sections present

### Remove
- Nothing removed, only enhancing

## Implementation Plan
1. Update constants block for easy editing (USER_NAME, BALANCE, CREDIT_LIMIT, CREDIT_USED, LOAN_VALUE, INVESTMENT_VALUE)
2. Rebuild header to include greeting row below icons
3. Add PixScreen, PayScreen, TransferScreen simulated sub-screens with back navigation
4. Add Empréstimo, Investimentos, NuShopping, MeusCartões section cards
5. Ensure all quick action buttons navigate to their respective screens
6. Keep all existing functionality (PIN login, balance edit, notifications, transactions)
